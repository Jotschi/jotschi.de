
public class Example  implements KeyboardEventListener {

    static GlobalEventListener gl;

	public static void main(String[] args) throws Exception  
	{
		Example inst = new Example();
		gl = new GlobalEventListener();
	  	gl.addKeyboardEventListener(inst);
	}
			
    public void GlobalKeyPressed( KeyboardEvent event )
	{
    	
		System.out.println( "Key Pressed: " + event.getVirtualKeyCode() );
	}

	public void GlobalKeyReleased( KeyboardEvent event )
	{
		System.out.println( "Key Released: " + event.getVirtualKeyCode() );
	}
	
}
